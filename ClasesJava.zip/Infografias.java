public class Infografias {
    // Atributos
    private String imagen;
    private String tamano;

    // Constructor
    public Infografias(String imagen, String tamano) {
        this.imagen = imagen;
        this.tamano = tamano;
    }

    // Métodos
    public boolean ampliar() {
        // Lógica para ampliar la infografía
        return true;
    }

    public boolean descargar() {
        // Lógica para descargar la infografía
        return true;
    }

    // Getters y Setters (omitiendo por brevedad)
    // ...
}
